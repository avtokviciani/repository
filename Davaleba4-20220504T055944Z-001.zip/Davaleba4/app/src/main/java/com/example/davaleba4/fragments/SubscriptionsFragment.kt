package com.example.davaleba4.fragments

import androidx.fragment.app.Fragment
import com.example.davaleba4.R

class SubscriptionsFragment : Fragment(R.layout.fragment_subscriptions) {
}