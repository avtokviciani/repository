package com.example.davaleba4.fragments

import androidx.fragment.app.Fragment
import com.example.davaleba4.R

class NotificationFragment: Fragment(R.layout.fragment_notification) {
}